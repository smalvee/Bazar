<div>
	<p>Name: {{ $array['name'] }}</p>
	<p>Email: {{ $array['email'] }}</p>
	<p>Phone: {{ $array['phone'] }}</p>
	<p>Company: {{ $array['company'] }}</p>
	<p>Message: {{ $array['message'] }}</p>
</div>